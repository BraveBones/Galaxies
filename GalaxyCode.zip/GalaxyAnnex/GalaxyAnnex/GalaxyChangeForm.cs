﻿using GalaxyAnnex.MyModels;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GalaxyAnnex
{
    public partial class GalaxyChangeForm : Form
    {
        AllData allData;
        Galaxy galaxyNow;
        bool close;
        public GalaxyChangeForm(Galaxy galaxyNow)
        {
            InitializeComponent();
            this.allData = new AllData();
            this.galaxyNow = galaxyNow;
            textBox1.Text = galaxyNow.GalaxyName;

        }

        bool check = true;
        private void button2_Click(object sender, EventArgs e)
        {
            foreach(var temp in allData.Galaxies)
            {
                if(temp.GalaxyName == galaxyNow.GalaxyName)
                {
                    if (textBox1.Text != "")
                    {
                        temp.GalaxyName = textBox1.Text;
                    }
                    if (pictureBox1.Image != null)
                    {
                        temp.GalaxyImage = pictureBox1.Image;
                    }
                }
            }
            allData.Save();
            this.Hide();
            check = false;
        }


        private void pictureBox1_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog1 = new OpenFileDialog();
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                pictureBox1.Image = new Bitmap(openFileDialog1.FileName);
            }
        }

        private void GalaxyChangeForm_FormClosing(object sender, FormClosingEventArgs e)
        {
                var res = MessageBox.Show("Save data before exit?", "", MessageBoxButtons.YesNoCancel);
                switch (res)
                {
                    case DialogResult.Cancel:
                        e.Cancel = true;
                        close = true;
                        break;
                    case DialogResult.Yes:
                        allData.Save();
                        break;
                    case DialogResult.No:
                        break;
                }
            }

        private void GalaxyChangeForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            if(close)
            {
                this.Close();
            }
        }
    }
}

