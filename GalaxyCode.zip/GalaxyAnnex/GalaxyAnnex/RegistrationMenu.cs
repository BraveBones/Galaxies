﻿using GalaxyAnnex.MyModels;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GalaxyAnnex
{
    public partial class RegistrationMenu : Form
    {
        AllData allData;
        //constuctor
        public RegistrationMenu(AllData allData)
        {
            InitializeComponent();
            PassWordPath();
            this.allData = allData;
        }
        //to close the app
        private void pictureBox4_Click(object sender, EventArgs e)
        {
            this.Close();
        }


        //to make in password field instead of numbers - * 
        public void PassWordPath()
        {
            textBox5.MaxLength = 10;
            textBox5.PasswordChar = '*';
            
        }
        //to move this form
        Point point;

        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
            if(e.Button == MouseButtons.Left)
            {
                this.Left += e.X - point.X;
                this.Top += e.Y - point.Y;
            }
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            point = new Point(e.X, e.Y);
        }
        //to register we use some if and if all of this is clear - we add new user
        private void button2_Click(object sender, EventArgs e)
        {
            bool check = true;
            if(textBox5.Text.Length < 5)
            {
                MessageBox.Show("You need to write at least 5 characters in Password");
                return;
            }
            User UserCheck = new User
            {
                Name = textBox2.Text,
                Password = textBox5.Text
            };

            foreach(User user in allData.Users)
            {
                if(UserCheck.Name == user.Name)
                {
                    MessageBox.Show("This nickname is used");
                    check = false;
                    break;
                }
            }
            if (check)
            {
                MessageBox.Show("Your nickname- " + textBox2.Text + " password- " + textBox5.Text);
                allData.Users.Add(UserCheck);
                allData.Save();
                this.Hide();
            }
        }
    }
}
