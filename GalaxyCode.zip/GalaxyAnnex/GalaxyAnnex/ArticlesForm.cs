﻿using GalaxyAnnex.MyModels;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GalaxyAnnex
{
    public partial class ArticlesForm : Form
    {
        AllData allData;
        bool close;
        public ArticlesForm(AllData allData)
        {
            InitializeComponent();
            this.allData = allData;
            foreach (var temp in allData.Galaxies)
            {
                AllGalaxiesBox.Items.Add(temp.GalaxyName);
            }
            if(allData.CurrentUser.Name == "admin")
            {
                menuStrip1.Visible = true;
            }
            else
            {
                menuStrip1.Visible = false;
            }
        }
        //method to display selected galaxy
        private void AllGalaxiesBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            for (int i = 0; i < AllGalaxiesBox.Items.Count; i++)
            {
                if (AllGalaxiesBox.GetItemChecked(i))
                {
                    foreach (var temp in allData.Galaxies)
                    {

                        if (temp.AllStars.Count > 0)
                        {
                            if (temp.GalaxyName == AllGalaxiesBox.GetItemText(AllGalaxiesBox.Items[i]))
                            {
                                AllStarsBox.Items.Clear();
                                tempGalaxy = temp;
                                foreach (var megaTemp in temp.AllStars)
                                    AllStarsBox.Items.Add(megaTemp.StarName);
                                GalaxyImage.Image = temp.GalaxyImage;
                                tempGalaxy.FindTheBrightest(tempGalaxy);
                                InfoStar.Clear();
                                InfoStar.Text += "brightest " + tempGalaxy.TheBrightest.StarName + Environment.NewLine;

                                GalaxyPhotoText.Text = "Galaxy picture: " + temp.GalaxyName;
                                return;
                            }
                        }
                        else
                        {
                            MessageBox.Show("This galaxy is empty");
                            return;
                        }
                    }
                }
            }
        }
        //method to display selected star
        private void AllStarsBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            for (int i = 0; i < AllStarsBox.Items.Count; i++)
            {
                if (AllStarsBox.GetItemChecked(i))
                {
                    foreach (var j in tempGalaxy.AllStars)
                    {
                        if (j.StarName == AllStarsBox.GetItemText(AllStarsBox.Items[i]))
                        {
                            InfoStar.Clear();
                            InfoStar.Text += "Name: " + j.StarName + Environment.NewLine + "Position: " + j.Position + Environment.NewLine + "Time to watch" + j.TimeToWatch + Environment.NewLine + "Distance: " + j.Distance + Environment.NewLine + "Apparent Magnitude: " + j.ApparentMagnitude + Environment.NewLine;
                            StarPicLab.Text = "Star picture " + j.StarName;
                            StarPictureBox.Image = j.StarImage;
                            return;
                        }
                    }

                }
            }
        }
        Galaxy tempGalaxy;
        //to delete privious galaxy
        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            List<Galaxy> deletedGalaxy = new List<Galaxy>();
            for (int i = 0; i < AllGalaxiesBox.Items.Count; i++)
            {
                if (AllGalaxiesBox.GetItemChecked(i))
                {
                    foreach (var j in allData.Galaxies)
                    {
                        if (j.GalaxyName == AllGalaxiesBox.GetItemText(AllGalaxiesBox.Items[i]))
                        {
                            deletedGalaxy.Add(j);
                        }
                    }
                }

            }
            foreach (var k in deletedGalaxy)
            {
                allData.Galaxies.Remove(k);
            }
            DeletePart();
        }
        //the save
        private void DeletePart()
        {
            AllGalaxiesBox.Items.Clear();
            foreach (var temp in allData.Galaxies)
            {
                AllGalaxiesBox.Items.Add(temp.GalaxyName);
            }
        }
        //edit(open new WF) to change Galaxy
        private void editSelectedToolStripMenuItem_Click(object sender, EventArgs e)
        {

            for (int i = 0; i < AllGalaxiesBox.Items.Count; i++)
            {
                if (AllGalaxiesBox.GetItemChecked(i))
                {
                    foreach (var temp in allData.Galaxies)
                    {
                        if (temp.GalaxyName == AllGalaxiesBox.GetItemText(AllGalaxiesBox.Items[i]))
                        {
                            GalaxyChangeForm galaxyChange = new GalaxyChangeForm(temp);
                            galaxyChange.Show();
                        }
                    }
                }
            }
            allData.Load();
            FindMethod();
            DeletePart();
        }
        // to remove from checkbox galaxy
        private void deleteToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            List<Star> deletedStar = new List<Star>();
            for (int i = 0; i < AllStarsBox.Items.Count; i++)
            {
                if (AllStarsBox.GetItemChecked(i))
                {
                    foreach (var j in tempGalaxy.AllStars)
                    {
                        if (j.StarName == AllStarsBox.GetItemText(AllStarsBox.Items[i]))
                        {
                            deletedStar.Add(j);
                        }
                    }
                }

            }
            foreach (var k in deletedStar)
            {
                tempGalaxy.AllStars.Remove(k);
            }
            DeleteStarPart();
        }
        // to remove from checkbox star
        private void DeleteStarPart()
        {
            AllStarsBox.Items.Clear();
            FindMethod();
            DeletePart();
            foreach (var check in allData.Galaxies)
            {
                if(check.GalaxyName == tempGalaxy.GalaxyName)
                {
                    foreach (var temp122 in check.AllStars)
                    {
                        AllStarsBox.Items.Add(temp122.StarName);

                    }
                    return;
                }
            }

        }
        //edit(open new WF) to change Star
        private void editStarToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < AllStarsBox.Items.Count; i++)
            {
                if (AllStarsBox.GetItemChecked(i))
                {
                    foreach (var j in tempGalaxy.AllStars)
                    {
                        if (j.StarName == AllStarsBox.GetItemText(AllStarsBox.Items[i]))
                        {
                            EditStarForm tempEditor = new EditStarForm(j, tempGalaxy);
                            tempEditor.Show();

                        }
                    }
                }

            }
            allData.Load();
            FindMethod();
            DeleteStarPart();
            this.Close();
        }
        //to find method(find the star)
        private void FindMethod()
        {
            for (int i = 0; i < AllGalaxiesBox.Items.Count; i++)
            {
                if (AllGalaxiesBox.GetItemChecked(i))
                {
                    foreach (var temp in allData.Galaxies)
                    {

                        if (temp.AllStars.Count > 0)
                        {
                            if (temp.GalaxyName == AllGalaxiesBox.GetItemText(AllGalaxiesBox.Items[i]))
                            {
                                tempGalaxy = temp;
                            }
                        }
                    }
                }
            }
        }

        private void ArticlesForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            var res = MessageBox.Show("Save data before exit?", "", MessageBoxButtons.YesNoCancel);
            switch (res)
            {
                case DialogResult.Cancel:
                    e.Cancel = true;
                    close = true;
                    break;
                case DialogResult.Yes:
                    allData.Save();
                    break;
                case DialogResult.No:
                    break;
            }
        }

        private void ArticlesForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            if(close)
            {
                this.Close();
            }
        }
    }
}
