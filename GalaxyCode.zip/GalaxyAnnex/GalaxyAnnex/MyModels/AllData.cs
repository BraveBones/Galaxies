﻿using GalaxyAnnex.DataSaver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GalaxyAnnex.MyModels
{
    [Serializable]
    public class AllData
    {
        public List<Galaxy> Galaxies {private set; get; }
        public List<User> Users {private set; get; }
        public Admin Admin {private set; get; }
        public User CurrentUser { private set; get; }

        public string TextInChat { set; get; }

        public AllData()
        {
            Galaxies = new List<Galaxy>();
            Admin = new Admin()
            {
                Name = "admin",
                Password = "admin",
            };
            Users = new List<User>();
            CurrentUser = new User();
            Users.Add(Admin);
            this.Load();
        }



        public void Save()
        {
            new SaverLoader(this).Save();
        }

        public void Load()
        {
            new SaverLoader(this).Load();
        }

    }
}
