﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GalaxyAnnex.MyModels
{
    [Serializable]
    public class Star
    {
        public string StarName { get; set; }
        public double ApparentMagnitude { get; set; }

        public double Distance { get; set; }

        public string Position { get; set; }

        public string TimeToWatch { get; set; }
        public Image StarImage { set; get; }

    }
}
