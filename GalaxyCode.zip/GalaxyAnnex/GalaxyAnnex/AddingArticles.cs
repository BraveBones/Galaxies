﻿using GalaxyAnnex.MyModels;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GalaxyAnnex
{
    public partial class AddingArticles : Form
    {
        AllData allData;
        public Galaxy galaxyNow;
        public AddingArticles(AllData allData)
        {
            InitializeComponent();
            this.allData = allData;
            galaxyNow = new Galaxy();
        }
        //open new form to change star
        private void button1_Click(object sender, EventArgs e)
        {
            AddStar addStar = new AddStar(allData, galaxyNow);
            addStar.Show();
        }
        //mover 
        Point point;
        private void panel2_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Left += e.X - point.X;
                this.Top += e.Y - point.Y;

            }
        }

        private void panel2_MouseDown(object sender, MouseEventArgs e)
        {
            point = new Point(e.X, e.Y);
        }
        //close button
        private void pictureBox4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        //to check and add new galaxy
        bool check = false;
        private void button2_Click(object sender, EventArgs e)
        {
            foreach(var i in allData.Galaxies)
            {
                if(GalaxyNameBox.Text == i.GalaxyName)
                {
                    MessageBox.Show("This galaxy is added!");
                    return;
                }
            }
            allData.Galaxies.Add(new Galaxy() { GalaxyName = GalaxyNameBox.Text, GalaxyImage = PictureChangeImageBox.Image });
            allData.Save();
            this.Hide();
            check = true;
        }
        //to cover form
        private void pictureBox3_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }
        //to add image
        private void pictureBox1_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                PictureChangeImageBox.Image = new Bitmap(openFileDialog1.FileName);
            }
        }

        private void CloseButtonPictureBox_Click(object sender, EventArgs e)
        {
            AddingArticles_FormClosing();
            this.Close();

        }

        private void AddingArticles_FormClosing()
        {
            FormClosingEventArgs e = new FormClosingEventArgs(CloseReason.None, true);
            if (!check)
            {

                var res = MessageBox.Show("Save data before exit?", "", MessageBoxButtons.YesNoCancel);
                switch (res)
                {
                    case DialogResult.Cancel:
                        e.Cancel = true;
                        break;
                    case DialogResult.Yes:
                        allData.Save();
                        break;
                    case DialogResult.No:
                        break;
                }
            }
        }
    }
}
