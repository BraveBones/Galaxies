﻿using GalaxyAnnex.MyModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Windows.Forms;

namespace GalaxyAnnex.DataSaver
{
    class SaverLoader
    {

        AllData allData;
        const string filePath = "AllData.bin";

        public SaverLoader(AllData allData)
        {
            this.allData = allData;
        }

        public void Save()
        {
            using (Stream stream = File.Create(filePath))
            {
                var serializer = new BinaryFormatter();
                serializer.Serialize(stream, allData);
            }
        }

        public void Load()
        {
            try
            {
                using (Stream stream = File.OpenRead(filePath))
                {
                    var serializer = new BinaryFormatter();
                    AllData temp = (AllData)serializer.Deserialize(stream);

                    Copy(temp.Galaxies, allData.Galaxies);
                    Copy(temp.Users, allData.Users);
                    allData.TextInChat = temp.TextInChat;

                }

                void Copy<T>(List<T> from, List<T> to)
                {
                    to.Clear();
                    to.AddRange(from);
                }
            }
            catch
            {
                MessageBox.Show("Niot valid data");
            }
        }
    }
}
