﻿namespace GalaxyAnnex
{
    partial class App
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(App));
            this.MenuPanel = new System.Windows.Forms.Panel();
            this.SubPanel = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.MenuButton = new System.Windows.Forms.Button();
            this.Articles = new System.Windows.Forms.Button();
            this.ChatButton = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.MainPictureBox = new System.Windows.Forms.PictureBox();
            this.MenuTextLabel = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.HelloLabel = new System.Windows.Forms.Label();
            this.NameLab = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.MaximizePictureBox = new System.Windows.Forms.PictureBox();
            this.CoverPictureBox = new System.Windows.Forms.PictureBox();
            this.ClosePictureBox = new System.Windows.Forms.PictureBox();
            this.ArticlePanel = new System.Windows.Forms.Panel();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addStarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addGalaxyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutGalaxiesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.helpToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.HelpMenu = new GalaxyAnnex.Help();
            this.main1 = new GalaxyAnnex.Main1();
            this.MenuPanel.SuspendLayout();
            this.SubPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MainPictureBox)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MaximizePictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.CoverPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ClosePictureBox)).BeginInit();
            this.ArticlePanel.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // MenuPanel
            // 
            this.MenuPanel.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.MenuPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(122)))), ((int)(((byte)(55)))), ((int)(((byte)(118)))));
            this.MenuPanel.Controls.Add(this.SubPanel);
            this.MenuPanel.Controls.Add(this.panel2);
            this.MenuPanel.Controls.Add(this.MainPictureBox);
            this.MenuPanel.Controls.Add(this.MenuTextLabel);
            this.MenuPanel.Dock = System.Windows.Forms.DockStyle.Left;
            this.MenuPanel.Location = new System.Drawing.Point(0, 0);
            this.MenuPanel.Name = "MenuPanel";
            this.MenuPanel.Size = new System.Drawing.Size(347, 761);
            this.MenuPanel.TabIndex = 0;
            this.MenuPanel.MouseDown += new System.Windows.Forms.MouseEventHandler(this.MenuPanel_MouseDown);
            this.MenuPanel.MouseMove += new System.Windows.Forms.MouseEventHandler(this.MenuPanel_MouseMove);
            // 
            // SubPanel
            // 
            this.SubPanel.Controls.Add(this.button1);
            this.SubPanel.Controls.Add(this.panel4);
            this.SubPanel.Controls.Add(this.MenuButton);
            this.SubPanel.Controls.Add(this.Articles);
            this.SubPanel.Controls.Add(this.ChatButton);
            this.SubPanel.Location = new System.Drawing.Point(3, 192);
            this.SubPanel.Name = "SubPanel";
            this.SubPanel.Size = new System.Drawing.Size(344, 260);
            this.SubPanel.TabIndex = 7;
            // 
            // button1
            // 
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Image = global::GalaxyAnnex.Properties.Resources.icons8_информация_42;
            this.button1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button1.Location = new System.Drawing.Point(15, 195);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(329, 65);
            this.button1.TabIndex = 6;
            this.button1.Text = "Help";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(95)))), ((int)(((byte)(77)))), ((int)(((byte)(221)))));
            this.panel4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.panel4.Location = new System.Drawing.Point(0, 0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(18, 65);
            this.panel4.TabIndex = 5;
            // 
            // MenuButton
            // 
            this.MenuButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.MenuButton.FlatAppearance.BorderSize = 0;
            this.MenuButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.MenuButton.Image = global::GalaxyAnnex.Properties.Resources.icons8_главная_страница_42;
            this.MenuButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.MenuButton.Location = new System.Drawing.Point(9, 3);
            this.MenuButton.Name = "MenuButton";
            this.MenuButton.Size = new System.Drawing.Size(329, 65);
            this.MenuButton.TabIndex = 1;
            this.MenuButton.Text = "Menu";
            this.MenuButton.UseVisualStyleBackColor = true;
            this.MenuButton.Click += new System.EventHandler(this.MenuButton_Click);
            // 
            // Articles
            // 
            this.Articles.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Articles.FlatAppearance.BorderSize = 0;
            this.Articles.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Articles.Image = global::GalaxyAnnex.Properties.Resources.icons8_новости_42;
            this.Articles.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Articles.Location = new System.Drawing.Point(15, 132);
            this.Articles.Name = "Articles";
            this.Articles.Size = new System.Drawing.Size(329, 65);
            this.Articles.TabIndex = 3;
            this.Articles.Text = "Articles";
            this.Articles.UseVisualStyleBackColor = true;
            this.Articles.Click += new System.EventHandler(this.Articles_Click);
            // 
            // ChatButton
            // 
            this.ChatButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ChatButton.FlatAppearance.BorderSize = 0;
            this.ChatButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ChatButton.Image = global::GalaxyAnnex.Properties.Resources.icons8_cообщение_облачко_42;
            this.ChatButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ChatButton.Location = new System.Drawing.Point(12, 71);
            this.ChatButton.Name = "ChatButton";
            this.ChatButton.Size = new System.Drawing.Size(329, 65);
            this.ChatButton.TabIndex = 4;
            this.ChatButton.Text = "Chat";
            this.ChatButton.UseVisualStyleBackColor = true;
            this.ChatButton.Click += new System.EventHandler(this.ChatButton_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Black;
            this.panel2.Location = new System.Drawing.Point(3, 101);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(347, 1);
            this.panel2.TabIndex = 6;
            // 
            // MainPictureBox
            // 
            this.MainPictureBox.Image = global::GalaxyAnnex.Properties.Resources.space1;
            this.MainPictureBox.Location = new System.Drawing.Point(109, 9);
            this.MainPictureBox.Name = "MainPictureBox";
            this.MainPictureBox.Size = new System.Drawing.Size(102, 86);
            this.MainPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.MainPictureBox.TabIndex = 2;
            this.MainPictureBox.TabStop = false;
            // 
            // MenuTextLabel
            // 
            this.MenuTextLabel.AutoSize = true;
            this.MenuTextLabel.Font = new System.Drawing.Font("Courier New", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MenuTextLabel.ForeColor = System.Drawing.SystemColors.Info;
            this.MenuTextLabel.Location = new System.Drawing.Point(12, 33);
            this.MenuTextLabel.Name = "MenuTextLabel";
            this.MenuTextLabel.Size = new System.Drawing.Size(91, 36);
            this.MenuTextLabel.TabIndex = 0;
            this.MenuTextLabel.Text = "Menu";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(47)))), ((int)(((byte)(96)))));
            this.panel1.Controls.Add(this.HelloLabel);
            this.panel1.Controls.Add(this.NameLab);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(347, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1093, 95);
            this.panel1.TabIndex = 3;
            // 
            // HelloLabel
            // 
            this.HelloLabel.AutoSize = true;
            this.HelloLabel.Font = new System.Drawing.Font("Courier New", 12F);
            this.HelloLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(161)))), ((int)(((byte)(251)))));
            this.HelloLabel.Location = new System.Drawing.Point(-6, 18);
            this.HelloLabel.Name = "HelloLabel";
            this.HelloLabel.Size = new System.Drawing.Size(148, 36);
            this.HelloLabel.TabIndex = 9;
            this.HelloLabel.Text = "Hello, ";
            // 
            // NameLab
            // 
            this.NameLab.AutoSize = true;
            this.NameLab.BackColor = System.Drawing.Color.Transparent;
            this.NameLab.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.NameLab.Font = new System.Drawing.Font("Courier New", 12F);
            this.NameLab.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(161)))), ((int)(((byte)(251)))));
            this.NameLab.Location = new System.Drawing.Point(6, 54);
            this.NameLab.Name = "NameLab";
            this.NameLab.Size = new System.Drawing.Size(0, 36);
            this.NameLab.TabIndex = 6;
            // 
            // panel3
            // 
            this.panel3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.panel3.Controls.Add(this.MaximizePictureBox);
            this.panel3.Controls.Add(this.CoverPictureBox);
            this.panel3.Controls.Add(this.ClosePictureBox);
            this.panel3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panel3.Location = new System.Drawing.Point(975, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(121, 36);
            this.panel3.TabIndex = 8;
            // 
            // MaximizePictureBox
            // 
            this.MaximizePictureBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(47)))), ((int)(((byte)(96)))));
            this.MaximizePictureBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.MaximizePictureBox.Image = global::GalaxyAnnex.Properties.Resources.icons8_изображение_в_картинке_42__1_;
            this.MaximizePictureBox.Location = new System.Drawing.Point(35, 0);
            this.MaximizePictureBox.Name = "MaximizePictureBox";
            this.MaximizePictureBox.Size = new System.Drawing.Size(51, 36);
            this.MaximizePictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.MaximizePictureBox.TabIndex = 0;
            this.MaximizePictureBox.TabStop = false;
            this.MaximizePictureBox.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // CoverPictureBox
            // 
            this.CoverPictureBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(47)))), ((int)(((byte)(96)))));
            this.CoverPictureBox.Dock = System.Windows.Forms.DockStyle.Left;
            this.CoverPictureBox.Image = global::GalaxyAnnex.Properties.Resources.icons8_горизонтальная_линия_42;
            this.CoverPictureBox.Location = new System.Drawing.Point(0, 0);
            this.CoverPictureBox.Name = "CoverPictureBox";
            this.CoverPictureBox.Size = new System.Drawing.Size(35, 36);
            this.CoverPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.CoverPictureBox.TabIndex = 1;
            this.CoverPictureBox.TabStop = false;
            this.CoverPictureBox.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // ClosePictureBox
            // 
            this.ClosePictureBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(47)))), ((int)(((byte)(96)))));
            this.ClosePictureBox.Dock = System.Windows.Forms.DockStyle.Right;
            this.ClosePictureBox.Image = global::GalaxyAnnex.Properties.Resources.icons8_удалить_42__1_;
            this.ClosePictureBox.Location = new System.Drawing.Point(86, 0);
            this.ClosePictureBox.Name = "ClosePictureBox";
            this.ClosePictureBox.Size = new System.Drawing.Size(35, 36);
            this.ClosePictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.ClosePictureBox.TabIndex = 2;
            this.ClosePictureBox.TabStop = false;
            this.ClosePictureBox.Click += new System.EventHandler(this.pictureBox4_Click);
            // 
            // ArticlePanel
            // 
            this.ArticlePanel.BackColor = System.Drawing.Color.DarkMagenta;
            this.ArticlePanel.Controls.Add(this.HelpMenu);
            this.ArticlePanel.Controls.Add(this.main1);
            this.ArticlePanel.Controls.Add(this.button3);
            this.ArticlePanel.Controls.Add(this.button2);
            this.ArticlePanel.Controls.Add(this.textBox2);
            this.ArticlePanel.Controls.Add(this.menuStrip1);
            this.ArticlePanel.Controls.Add(this.textBox1);
            this.ArticlePanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ArticlePanel.Location = new System.Drawing.Point(347, 95);
            this.ArticlePanel.Name = "ArticlePanel";
            this.ArticlePanel.Size = new System.Drawing.Size(1093, 666);
            this.ArticlePanel.TabIndex = 9;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(193, 579);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(125, 39);
            this.button3.TabIndex = 12;
            this.button3.Text = "Send";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(46, 580);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(141, 38);
            this.button2.TabIndex = 11;
            this.button2.Text = "Save Chat";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("Segoe Script", 13.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.Location = new System.Drawing.Point(378, 541);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(632, 66);
            this.textBox2.TabIndex = 10;
            this.textBox2.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox2_KeyDown);
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(50)))), ((int)(((byte)(96)))));
            this.menuStrip1.GripMargin = new System.Windows.Forms.Padding(2, 2, 0, 2);
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(32, 32);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.addToolStripMenuItem,
            this.helpToolStripMenuItem,
            this.helpToolStripMenuItem1});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1093, 40);
            this.menuStrip1.TabIndex = 13;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.saveToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(72, 36);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // saveToolStripMenuItem
            // 
            this.saveToolStripMenuItem.Name = "saveToolStripMenuItem";
            this.saveToolStripMenuItem.Size = new System.Drawing.Size(199, 44);
            this.saveToolStripMenuItem.Text = "Save";
            this.saveToolStripMenuItem.Click += new System.EventHandler(this.saveToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(199, 44);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // addToolStripMenuItem
            // 
            this.addToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addStarToolStripMenuItem,
            this.addGalaxyToolStripMenuItem});
            this.addToolStripMenuItem.Name = "addToolStripMenuItem";
            this.addToolStripMenuItem.Size = new System.Drawing.Size(78, 36);
            this.addToolStripMenuItem.Text = "Add";
            // 
            // addStarToolStripMenuItem
            // 
            this.addStarToolStripMenuItem.Name = "addStarToolStripMenuItem";
            this.addStarToolStripMenuItem.Size = new System.Drawing.Size(268, 44);
            this.addStarToolStripMenuItem.Text = "Add Star";
            this.addStarToolStripMenuItem.DropDownItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.addStarToolStripMenuItem_DropDownItemClicked);
            this.addStarToolStripMenuItem.MouseHover += new System.EventHandler(this.addStarToolStripMenuItem_MouseHover);
            // 
            // addGalaxyToolStripMenuItem
            // 
            this.addGalaxyToolStripMenuItem.Name = "addGalaxyToolStripMenuItem";
            this.addGalaxyToolStripMenuItem.Size = new System.Drawing.Size(268, 44);
            this.addGalaxyToolStripMenuItem.Text = "Add Galaxy";
            this.addGalaxyToolStripMenuItem.Click += new System.EventHandler(this.addGalaxyToolStripMenuItem_Click);
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aboutGalaxiesToolStripMenuItem});
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(112, 36);
            this.helpToolStripMenuItem.Text = "Articles";
            // 
            // aboutGalaxiesToolStripMenuItem
            // 
            this.aboutGalaxiesToolStripMenuItem.Name = "aboutGalaxiesToolStripMenuItem";
            this.aboutGalaxiesToolStripMenuItem.Size = new System.Drawing.Size(307, 44);
            this.aboutGalaxiesToolStripMenuItem.Text = "About Galaxies";
            this.aboutGalaxiesToolStripMenuItem.Click += new System.EventHandler(this.aboutGalaxiesToolStripMenuItem_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(36, 62);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBox1.Size = new System.Drawing.Size(964, 454);
            this.textBox1.TabIndex = 9;
            // 
            // helpToolStripMenuItem1
            // 
            this.helpToolStripMenuItem1.Name = "helpToolStripMenuItem1";
            this.helpToolStripMenuItem1.Size = new System.Drawing.Size(85, 36);
            this.helpToolStripMenuItem1.Text = "Help";
            this.helpToolStripMenuItem1.Click += new System.EventHandler(this.helpToolStripMenuItem1_Click);
            // 
            // HelpMenu
            // 
            this.HelpMenu.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.HelpMenu.BackColor = System.Drawing.Color.DarkMagenta;
            this.HelpMenu.Location = new System.Drawing.Point(3, 40);
            this.HelpMenu.Name = "HelpMenu";
            this.HelpMenu.Size = new System.Drawing.Size(1093, 623);
            this.HelpMenu.TabIndex = 15;
            // 
            // main1
            // 
            this.main1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.main1.BackColor = System.Drawing.Color.DarkMagenta;
            this.main1.Location = new System.Drawing.Point(6, 40);
            this.main1.Name = "main1";
            this.main1.Size = new System.Drawing.Size(1090, 623);
            this.main1.TabIndex = 14;
            // 
            // App
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(1440, 761);
            this.Controls.Add(this.ArticlePanel);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.MenuPanel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "App";
            this.Text = "Application";
            this.Load += new System.EventHandler(this.App_Load);
            this.MenuPanel.ResumeLayout(false);
            this.MenuPanel.PerformLayout();
            this.SubPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.MainPictureBox)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.MaximizePictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.CoverPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ClosePictureBox)).EndInit();
            this.ArticlePanel.ResumeLayout(false);
            this.ArticlePanel.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel MenuPanel;
        private System.Windows.Forms.PictureBox MainPictureBox;
        private System.Windows.Forms.Button MenuButton;
        private System.Windows.Forms.Label MenuTextLabel;
        private System.Windows.Forms.Button Articles;
        private System.Windows.Forms.PictureBox CoverPictureBox;
        private System.Windows.Forms.PictureBox ClosePictureBox;
        private System.Windows.Forms.PictureBox MaximizePictureBox;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button ChatButton;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel SubPanel;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label NameLab;
        private System.Windows.Forms.Panel ArticlePanel;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addStarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addGalaxyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutGalaxiesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.Label HelloLabel;
        private Main1 main1;
        private Help HelpMenu;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem1;
        //private UserInterface.Chat chat1;
    }
}