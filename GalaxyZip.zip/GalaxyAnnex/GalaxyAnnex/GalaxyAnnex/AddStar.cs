﻿using GalaxyAnnex.MyModels;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GalaxyAnnex
{
    public partial class AddStar : Form
    {
        AllData allData;
        Star nowStar;
        Galaxy galaxy;
        public AddStar(AllData allData, Galaxy galaxy)
        {
            InitializeComponent();
            this.allData = allData;
            nowStar = new Star();
            this.galaxy = galaxy;
            allData.FillTestData();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            allData.Save();
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            nowStar.StarName = StarNameTextBox.Text;
            nowStar.StarImage = StarImageBox.Image;
            foreach (var i in galaxy.AllStars)
            {
                if(i.StarName == nowStar.StarName)
                {
                    MessageBox.Show("This star is added!");
                    return;
                }
            }
            try
            {
                double result = double.Parse(APTextBox.Text);
                nowStar.ApparentMagnitude = result;
            }
            catch (FormatException)
            {
                MessageBox.Show("Not corrent amplitude");
                return;
            }

            try
            {
                double distanse = double.Parse(DistanceTextBox.Text);
                nowStar.Distance = distanse;
            }
            catch (FormatException)
            {
                MessageBox.Show("Not corrent distance");
                return;
            }

            try
            {
                string pos = PositionTextBox.Text;
                nowStar.Position = pos;
            }
            catch (FormatException)
            {
                MessageBox.Show("Not corrent possition");
                return;
            }

            try
            {
                string time = TimeToWatchTextBox.Text;
               if(time[2] == ':' && time[5] == ':')
                    nowStar.TimeToWatch = time;
                else
                {
                   MessageBox.Show("Not corrent time");
                    return;
                }
            }
            catch (FormatException)
            {
                MessageBox.Show("Not corrent time");
                return;
            }
            if (nowStar != null)
            {
                galaxy.AllStars.Add(nowStar);
                allData.Save();
            }
            this.Hide();
        }
        Point point;
        private void panel2_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Left += e.X - point.X;
                this.Top += e.Y - point.Y;

            }
        }

        private void panel2_MouseDown(object sender, MouseEventArgs e)
        {
            point = new Point(e.X, e.Y);
        }

        private void StarImageBox_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog1 = new OpenFileDialog();
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                StarImageBox.Image = new Bitmap(openFileDialog1.FileName);
            }
        }
    }
}
