﻿using GalaxyAnnex.MyModels;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GalaxyAnnex
{
    public partial class EditStarForm : Form
    {
        AllData allData;
        Star nowStar;
        Galaxy galaxy;
        public EditStarForm(Star currentStar, Galaxy galaxy)
        {
            InitializeComponent();
            allData = new AllData();
            nowStar = currentStar;
            this.galaxy = galaxy;
        }


        //button to change star
        private void button1_Click(object sender, EventArgs e)
        {
            foreach (var temp in allData.Galaxies)
            {
                if(temp.GalaxyName == galaxy.GalaxyName) {
                    foreach (var j in temp.AllStars)
                    {
                        if (j.StarName == nowStar.StarName)
                        {
                            if (textBox1.Text != "")
                                j.StarName = textBox1.Text;
                            if(StarImageBox.Image != null)
                                j.StarImage = StarImageBox.Image;
                            try
                            {
                                double result = double.Parse(textBox2.Text);
                                j.ApparentMagnitude = result;
                            }
                            catch (FormatException)
                            {
                            }

                            try
                            {
                                double distanse = double.Parse(textBox6.Text);
                                j.Distance = distanse;
                            }
                            catch (FormatException)
                            {
                            }

                            try
                            {
                                if (textBox5.Text != "")
                                {
                                    string pos = textBox5.Text;
                                    j.Position = pos;
                                }
                            }
                            catch (FormatException)
                            {
                            }

                            try
                            {
                                string time = textBox4.Text;
                                if(time[2] == ':' && time[5] == ':')
                                j.TimeToWatch = time;
                                else
                                {
                                    MessageBox.Show("Not corrent time");
                                }
                            }
                            catch (FormatException)
                            {
                                MessageBox.Show("Not corrent time");
                            }
                            catch(System.IndexOutOfRangeException)
                            {

                            }
                            allData.Save();
                            ArticlesForm yap = new ArticlesForm(allData);
                            yap.Show();
                            this.Close();
                            return;
                        }
                    }
                }
            }
        }
        //change the image
        private void StarImageBox_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog1 = new OpenFileDialog();
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                StarImageBox.Image = new Bitmap(openFileDialog1.FileName);
            }
        }

    }
}

