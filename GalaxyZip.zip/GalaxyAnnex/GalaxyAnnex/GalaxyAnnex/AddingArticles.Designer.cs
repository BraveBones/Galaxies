﻿namespace GalaxyAnnex
{
    partial class AddingArticles
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddingArticles));
            this.panel3 = new System.Windows.Forms.Panel();
            this.CoverButtonPictureBox = new System.Windows.Forms.PictureBox();
            this.CloseButtonPictureBox = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.SaveButton = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.GalaxyNameBox = new System.Windows.Forms.TextBox();
            this.GalaxyNameLabel = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.PictureChangeImageBox = new System.Windows.Forms.PictureBox();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.CoverButtonPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.CloseButtonPictureBox)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PictureChangeImageBox)).BeginInit();
            this.SuspendLayout();
            // 
            // panel3
            // 
            this.panel3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.panel3.Controls.Add(this.CoverButtonPictureBox);
            this.panel3.Controls.Add(this.CloseButtonPictureBox);
            this.panel3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panel3.Location = new System.Drawing.Point(609, 1);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(79, 36);
            this.panel3.TabIndex = 9;
            // 
            // CoverButtonPictureBox
            // 
            this.CoverButtonPictureBox.Image = global::GalaxyAnnex.Properties.Resources.icons8_горизонтальная_линия_42;
            this.CoverButtonPictureBox.Location = new System.Drawing.Point(0, -1);
            this.CoverButtonPictureBox.Name = "CoverButtonPictureBox";
            this.CoverButtonPictureBox.Size = new System.Drawing.Size(42, 37);
            this.CoverButtonPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.CoverButtonPictureBox.TabIndex = 0;
            this.CoverButtonPictureBox.TabStop = false;
            // 
            // CloseButtonPictureBox
            // 
            this.CloseButtonPictureBox.Image = global::GalaxyAnnex.Properties.Resources.icons8_удалить_42__1_;
            this.CloseButtonPictureBox.Location = new System.Drawing.Point(39, -1);
            this.CloseButtonPictureBox.Name = "CloseButtonPictureBox";
            this.CloseButtonPictureBox.Size = new System.Drawing.Size(40, 33);
            this.CloseButtonPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.CloseButtonPictureBox.TabIndex = 1;
            this.CloseButtonPictureBox.TabStop = false;
            this.CloseButtonPictureBox.Click += new System.EventHandler(this.CloseButtonPictureBox_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Black;
            this.panel1.Location = new System.Drawing.Point(0, 36);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1026, 1);
            this.panel1.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(488, 55);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(121, 25);
            this.label3.TabIndex = 16;
            this.label3.Text = "Add picture";
            // 
            // SaveButton
            // 
            this.SaveButton.Location = new System.Drawing.Point(229, 411);
            this.SaveButton.Name = "SaveButton";
            this.SaveButton.Size = new System.Drawing.Size(119, 49);
            this.SaveButton.TabIndex = 17;
            this.SaveButton.Text = "Save";
            this.SaveButton.UseVisualStyleBackColor = true;
            this.SaveButton.Click += new System.EventHandler(this.button2_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(688, 37);
            this.panel2.TabIndex = 18;
            this.panel2.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel2_MouseDown);
            this.panel2.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panel2_MouseMove);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(32, 32);
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // GalaxyNameBox
            // 
            this.GalaxyNameBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(47)))), ((int)(((byte)(96)))));
            this.GalaxyNameBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.GalaxyNameBox.Location = new System.Drawing.Point(68, 104);
            this.GalaxyNameBox.Multiline = true;
            this.GalaxyNameBox.Name = "GalaxyNameBox";
            this.GalaxyNameBox.Size = new System.Drawing.Size(159, 34);
            this.GalaxyNameBox.TabIndex = 21;
            // 
            // GalaxyNameLabel
            // 
            this.GalaxyNameLabel.AutoSize = true;
            this.GalaxyNameLabel.Location = new System.Drawing.Point(63, 55);
            this.GalaxyNameLabel.Name = "GalaxyNameLabel";
            this.GalaxyNameLabel.Size = new System.Drawing.Size(138, 25);
            this.GalaxyNameLabel.TabIndex = 22;
            this.GalaxyNameLabel.Text = "Galaxy name";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Black;
            this.panel4.Location = new System.Drawing.Point(68, 144);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(200, 1);
            this.panel4.TabIndex = 39;
            // 
            // PictureChangeImageBox
            // 
            this.PictureChangeImageBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(71)))), ((int)(((byte)(100)))));
            this.PictureChangeImageBox.Location = new System.Drawing.Point(412, 113);
            this.PictureChangeImageBox.Name = "PictureChangeImageBox";
            this.PictureChangeImageBox.Size = new System.Drawing.Size(269, 242);
            this.PictureChangeImageBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.PictureChangeImageBox.TabIndex = 19;
            this.PictureChangeImageBox.TabStop = false;
            this.PictureChangeImageBox.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // AddingArticles
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(47)))), ((int)(((byte)(96)))));
            this.ClientSize = new System.Drawing.Size(688, 472);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.GalaxyNameLabel);
            this.Controls.Add(this.GalaxyNameBox);
            this.Controls.Add(this.PictureChangeImageBox);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.SaveButton);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "AddingArticles";
            this.Text = "AddingArticles";
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.CoverButtonPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.CloseButtonPictureBox)).EndInit();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.PictureChangeImageBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.PictureBox CoverButtonPictureBox;
        private System.Windows.Forms.PictureBox CloseButtonPictureBox;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button SaveButton;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox PictureChangeImageBox;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.TextBox GalaxyNameBox;
        private System.Windows.Forms.Label GalaxyNameLabel;
        private System.Windows.Forms.Panel panel4;
    }
}