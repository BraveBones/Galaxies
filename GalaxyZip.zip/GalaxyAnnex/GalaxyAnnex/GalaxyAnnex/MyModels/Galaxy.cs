﻿ using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Forms;

namespace GalaxyAnnex.MyModels
{
    // All stars + the brightest star
    [Serializable]
    public class Galaxy
    {
        public Galaxy()
        {
            AllStars = new List<Star>();
        }
        public string GalaxyName { set; get; }
        public List<Star> AllStars { get; private set; }
        public Star TheBrightest { set; get; }
        public Image GalaxyImage { set; get; }

        public void FindTheBrightest(Galaxy galaxy)
        {
            Star temp = new Star() ;
            if (galaxy.AllStars.Count > 0) {
                temp = galaxy.AllStars[0];
            }
            else
            {
                return;
            }
            foreach(Star star in galaxy.AllStars)
            {
                if(temp.ApparentMagnitude < star.ApparentMagnitude)
                {
                    temp = star;
                }
            }
            TheBrightest = temp;
        }

    }

}
