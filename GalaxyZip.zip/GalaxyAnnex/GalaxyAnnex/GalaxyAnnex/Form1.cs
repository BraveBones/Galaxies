﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using GalaxyAnnex.MyModels;

namespace GalaxyAnnex
{
    public partial class EnterMenu : Form
    {
        AllData allData;
        public EnterMenu()
        {
            allData = new AllData();
            InitializeComponent();
            PassWordPath();
        }
        //close button
        private void pictureBox4_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        //to open registation form
        private void button2_Click(object sender, EventArgs e)
        {
            RegistrationMenu Wop = new RegistrationMenu(allData);
            Wop.Show();
        }
        //try to log in
        User user = new User();
        private void LogButton_Click(object sender, EventArgs e)
        {
            bool check = true;
            user.Name = UserBox.Text;
            user.Password = PasswordBox.Text;
            foreach(User temp in allData.Users)
            {
                if(temp.Name == user.Name && temp.Password == user.Password)
                {
                        check = false;
                        allData.CurrentUser.Name = temp.Name;
                        allData.CurrentUser.Password = temp.Password;

                    if (temp.Name == "admin" && temp.Password == "admin")
                    {
                        allData.CurrentUser.Name = "admin";
                        allData.CurrentUser.Password = "admin";
                    }
                        allData.Save();
                        App App = new App(allData);
                        App.Show();
                    

                }
            }

            if(check)
            {
                MessageBox.Show("Not corrent data input or you do not make account");
            }
            if(!check)
            {
                
                this.Hide();
            }
        }

        Point point;
        //mover
        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Left += e.X - point.X;
                this.Top += e.Y - point.Y;

            }
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            point = new Point(e.X, e.Y);
        }
        //to make passwordbox word - *
        public void PassWordPath()
        {
            PasswordBox.MaxLength = 10;
            PasswordBox.PasswordChar = '*';

        }
    }
}


