﻿namespace GalaxyAnnex
{
    partial class ArticlesForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.AllGalaxiesBox = new System.Windows.Forms.CheckedListBox();
            this.AllStarsBox = new System.Windows.Forms.CheckedListBox();
            this.InfoStar = new System.Windows.Forms.TextBox();
            this.GalaxyImage = new System.Windows.Forms.PictureBox();
            this.GalaxyPhotoText = new System.Windows.Forms.Label();
            this.StarPictureBox = new System.Windows.Forms.PictureBox();
            this.StarPicLab = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.editToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editSelectedToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editStarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.editStarToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.GalaxyImage)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.StarPictureBox)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // AllGalaxiesBox
            // 
            this.AllGalaxiesBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.AllGalaxiesBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(55)))), ((int)(((byte)(100)))));
            this.AllGalaxiesBox.FormattingEnabled = true;
            this.AllGalaxiesBox.HorizontalScrollbar = true;
            this.AllGalaxiesBox.Location = new System.Drawing.Point(12, 59);
            this.AllGalaxiesBox.MaximumSize = new System.Drawing.Size(418, 280);
            this.AllGalaxiesBox.Name = "AllGalaxiesBox";
            this.AllGalaxiesBox.Size = new System.Drawing.Size(302, 256);
            this.AllGalaxiesBox.TabIndex = 2;
            this.AllGalaxiesBox.SelectedIndexChanged += new System.EventHandler(this.AllGalaxiesBox_SelectedIndexChanged);
            // 
            // AllStarsBox
            // 
            this.AllStarsBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.AllStarsBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(55)))), ((int)(((byte)(100)))));
            this.AllStarsBox.FormattingEnabled = true;
            this.AllStarsBox.HorizontalScrollbar = true;
            this.AllStarsBox.Location = new System.Drawing.Point(440, 59);
            this.AllStarsBox.MaximumSize = new System.Drawing.Size(600, 260);
            this.AllStarsBox.Name = "AllStarsBox";
            this.AllStarsBox.Size = new System.Drawing.Size(324, 256);
            this.AllStarsBox.TabIndex = 3;
            this.AllStarsBox.SelectedIndexChanged += new System.EventHandler(this.AllStarsBox_SelectedIndexChanged);
            // 
            // InfoStar
            // 
            this.InfoStar.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.InfoStar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(55)))), ((int)(((byte)(100)))));
            this.InfoStar.Location = new System.Drawing.Point(827, 48);
            this.InfoStar.MaximumSize = new System.Drawing.Size(400, 280);
            this.InfoStar.Multiline = true;
            this.InfoStar.Name = "InfoStar";
            this.InfoStar.ReadOnly = true;
            this.InfoStar.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.InfoStar.Size = new System.Drawing.Size(286, 256);
            this.InfoStar.TabIndex = 4;
            // 
            // GalaxyImage
            // 
            this.GalaxyImage.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.GalaxyImage.Location = new System.Drawing.Point(12, 403);
            this.GalaxyImage.MaximumSize = new System.Drawing.Size(260, 219);
            this.GalaxyImage.Name = "GalaxyImage";
            this.GalaxyImage.Size = new System.Drawing.Size(260, 205);
            this.GalaxyImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.GalaxyImage.TabIndex = 5;
            this.GalaxyImage.TabStop = false;
            // 
            // GalaxyPhotoText
            // 
            this.GalaxyPhotoText.AllowDrop = true;
            this.GalaxyPhotoText.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.GalaxyPhotoText.AutoSize = true;
            this.GalaxyPhotoText.Location = new System.Drawing.Point(7, 353);
            this.GalaxyPhotoText.Name = "GalaxyPhotoText";
            this.GalaxyPhotoText.Size = new System.Drawing.Size(147, 25);
            this.GalaxyPhotoText.TabIndex = 6;
            this.GalaxyPhotoText.Text = "Galaxy Photo ";
            // 
            // StarPictureBox
            // 
            this.StarPictureBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.StarPictureBox.Location = new System.Drawing.Point(827, 377);
            this.StarPictureBox.MaximumSize = new System.Drawing.Size(260, 219);
            this.StarPictureBox.Name = "StarPictureBox";
            this.StarPictureBox.Size = new System.Drawing.Size(260, 219);
            this.StarPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.StarPictureBox.TabIndex = 7;
            this.StarPictureBox.TabStop = false;
            // 
            // StarPicLab
            // 
            this.StarPicLab.AllowDrop = true;
            this.StarPicLab.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.StarPicLab.AutoSize = true;
            this.StarPicLab.Location = new System.Drawing.Point(834, 336);
            this.StarPicLab.Name = "StarPicLab";
            this.StarPicLab.Size = new System.Drawing.Size(113, 25);
            this.StarPicLab.TabIndex = 8;
            this.StarPicLab.Text = "Star Photo";
            // 
            // menuStrip1
            // 
            this.menuStrip1.GripMargin = new System.Windows.Forms.Padding(2, 2, 0, 2);
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(32, 32);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.editToolStripMenuItem,
            this.editStarToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1125, 40);
            this.menuStrip1.TabIndex = 9;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // editToolStripMenuItem
            // 
            this.editToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.editSelectedToolStripMenuItem,
            this.deleteToolStripMenuItem});
            this.editToolStripMenuItem.Name = "editToolStripMenuItem";
            this.editToolStripMenuItem.Size = new System.Drawing.Size(75, 36);
            this.editToolStripMenuItem.Text = "Edit";
            // 
            // editSelectedToolStripMenuItem
            // 
            this.editSelectedToolStripMenuItem.Name = "editSelectedToolStripMenuItem";
            this.editSelectedToolStripMenuItem.Size = new System.Drawing.Size(284, 44);
            this.editSelectedToolStripMenuItem.Text = "Edit selected";
            this.editSelectedToolStripMenuItem.Click += new System.EventHandler(this.editSelectedToolStripMenuItem_Click);
            // 
            // deleteToolStripMenuItem
            // 
            this.deleteToolStripMenuItem.Name = "deleteToolStripMenuItem";
            this.deleteToolStripMenuItem.Size = new System.Drawing.Size(284, 44);
            this.deleteToolStripMenuItem.Text = "Delete";
            this.deleteToolStripMenuItem.Click += new System.EventHandler(this.deleteToolStripMenuItem_Click);
            // 
            // editStarToolStripMenuItem
            // 
            this.editStarToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.deleteToolStripMenuItem1,
            this.editStarToolStripMenuItem1});
            this.editStarToolStripMenuItem.Name = "editStarToolStripMenuItem";
            this.editStarToolStripMenuItem.Size = new System.Drawing.Size(122, 36);
            this.editStarToolStripMenuItem.Text = "Edit Star";
            // 
            // deleteToolStripMenuItem1
            // 
            this.deleteToolStripMenuItem1.Name = "deleteToolStripMenuItem1";
            this.deleteToolStripMenuItem1.Size = new System.Drawing.Size(236, 44);
            this.deleteToolStripMenuItem1.Text = "Delete";
            this.deleteToolStripMenuItem1.Click += new System.EventHandler(this.deleteToolStripMenuItem1_Click);
            // 
            // editStarToolStripMenuItem1
            // 
            this.editStarToolStripMenuItem1.Name = "editStarToolStripMenuItem1";
            this.editStarToolStripMenuItem1.Size = new System.Drawing.Size(236, 44);
            this.editStarToolStripMenuItem1.Text = "Edit Star";
            this.editStarToolStripMenuItem1.Click += new System.EventHandler(this.editStarToolStripMenuItem1_Click);
            // 
            // ArticlesForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(47)))), ((int)(((byte)(96)))));
            this.ClientSize = new System.Drawing.Size(1125, 676);
            this.Controls.Add(this.StarPicLab);
            this.Controls.Add(this.StarPictureBox);
            this.Controls.Add(this.GalaxyPhotoText);
            this.Controls.Add(this.GalaxyImage);
            this.Controls.Add(this.InfoStar);
            this.Controls.Add(this.AllStarsBox);
            this.Controls.Add(this.AllGalaxiesBox);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.MinimumSize = new System.Drawing.Size(1151, 747);
            this.Name = "ArticlesForm";
            this.Text = "ArticlesForm";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.ArticlesForm_FormClosing);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.ArticlesForm_FormClosed);
            ((System.ComponentModel.ISupportInitialize)(this.GalaxyImage)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.StarPictureBox)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckedListBox AllGalaxiesBox;
        private System.Windows.Forms.CheckedListBox AllStarsBox;
        private System.Windows.Forms.TextBox InfoStar;
        private System.Windows.Forms.PictureBox GalaxyImage;
        private System.Windows.Forms.Label GalaxyPhotoText;
        private System.Windows.Forms.PictureBox StarPictureBox;
        private System.Windows.Forms.Label StarPicLab;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem editToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem editSelectedToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem deleteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem editStarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem deleteToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem editStarToolStripMenuItem1;
    }
}