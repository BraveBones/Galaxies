﻿using GalaxyAnnex.MyModels;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GalaxyAnnex
{
    public partial class App : Form
    {
        AllData allData;
        public App(AllData allData)
        {
            this.allData = allData;
            InitializeComponent();
            NameLab.Text = allData.CurrentUser.Name;
            textBox1.Text = allData.TextInChat;
            textBox1.Visible = false;
            textBox2.Visible = false;
            button3.Visible = false;
            button2.Visible = false;
            HelpMenu.Visible = false;
            if (allData.CurrentUser.Name == "admin" && allData.CurrentUser.Password == "admin" || NameLab.Text == "admin")
            {
                menuStrip1.Visible = true;
                button2.Visible = true;
            }
            else
            {
                menuStrip1.Visible = false;
                button2.Visible = false;
            }
            button2.Visible = false;
        }
        //
        private void MenuButton_MouseHover(object sender, EventArgs e)
        {
            this.ForeColor = Color.FromArgb(156, 118, 227);
        }
        // to move i added this method
        Point point;
        private void MenuPanel_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Left += e.X - point.X;
                this.Top += e.Y - point.Y;
            }
        }
        // change the position of point(this point is a our annex)
        private void MenuPanel_MouseDown(object sender, MouseEventArgs e)
        {
            point = new Point(e.X, e.Y);
        }
        //close app
        private void pictureBox4_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        //change the size of app
        private void pictureBox2_Click(object sender, EventArgs e)
        {
            if(WindowState == FormWindowState.Normal)
            {
                WindowState = FormWindowState.Maximized;
            }
            else
            {
                WindowState = FormWindowState.Normal;
            }
        }
        //cover the app
        private void pictureBox3_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }
        // adder to menu strip
        private void App_Load(object sender, EventArgs e)
        {
            foreach (var temp in allData.Galaxies) {
              this.addStarToolStripMenuItem.DropDownItems.Add(temp.GalaxyName);
                }
        }
        //to open menu-articles
        private void Articles_Click(object sender, EventArgs e)
        {
                main1.Visible = true;
                ArticlePanel.Visible = true;
                panel4.Height = Articles.Height;
                panel4.Top = Articles.Top;
                panel4.BackColor = Color.FromArgb(24, 161, 251);
                ArticlesForm articleForm = new ArticlesForm(allData);
                articleForm.Show();
            


        }
        //to open menu-chat
        private void ChatButton_Click(object sender, EventArgs e)
        {
            panel4.Height = ChatButton.Height;
            panel4.Top = ChatButton.Top;
            panel4.BackColor = Color.FromArgb(95, 77, 221);
            main1.Visible = false;
            textBox1.Visible = true;
            textBox2.Visible = true;
            button3.Visible = true;
            button2.Visible = true;
            HelpMenu.Visible = false;
            if(NameLab.Text == "admin")
            {
                textBox1.ReadOnly = false;
                textBox2.ReadOnly = false;

            }
        }
        //its main page
        private void MenuButton_Click(object sender, EventArgs e)
        {
            panel4.Height = MenuButton.Height;
            panel4.Top = MenuButton.Top;
            panel4.BackColor = Color.FromArgb(172, 126, 241);
            textBox1.Visible = false;
            textBox2.Visible = false;
            button3.Visible = false;
            button2.Visible = false;
            main1.Visible = true;
            HelpMenu.Visible = false;
        }
        //help menu
        private void button1_Click(object sender, EventArgs e)
        {
            panel4.Height = button1.Height;
            panel4.Top = button1.Top;
            panel4.BackColor = Color.FromArgb(249, 118, 178);
            HelpMenu.Visible = true;
            textBox1.Visible = false;
            textBox2.Visible = false;
            button3.Visible = false;
            button2.Visible = false;
        }



        //its our chat properties
        private void button3_Click(object sender, EventArgs e)
        {
            string temp = allData.CurrentUser.Name + " said: " + textBox2.Text;
            if (temp != "")
            {
                textBox1.Text += temp + Environment.NewLine;
                textBox2.Clear();
                allData.TextInChat = textBox1.Text;
                allData.Save();
            }
        }
        //save chat
        private void button2_Click(object sender, EventArgs e)
        {
            allData.TextInChat = textBox1.Text;
            allData.Save();
        }
        //in menu-strip we can add galaxy and open new WF
        private void addGalaxyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddingArticles addArticles = new AddingArticles(allData);
            addArticles.Show();
        }
        //checker for a menu-stpit
        private void Test1()
        {
            this.addStarToolStripMenuItem.DropDownItems.Clear();
            foreach (var temp in allData.Galaxies)
            {
                this.addStarToolStripMenuItem.DropDownItems.Add(temp.GalaxyName);
            }
        }
        //to upload galaxies we use it
        private void addStarToolStripMenuItem_MouseHover(object sender, EventArgs e)
        {
            Test1();
        }
        //to upload stars we use it
        private void addStarToolStripMenuItem_DropDownItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            for (int i = 0; i < allData.Galaxies.Count; i++)
            {
                if (addStarToolStripMenuItem.DropDownItems[i].Pressed)
                {
                   
                            AddStar addStar = new AddStar(allData, allData.Galaxies[i]);
                            addStar.Show();
                    return;
                        
                }
            }
        }
        //to open article form
        private void aboutGalaxiesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ArticlesForm myForm = new ArticlesForm(allData);
            myForm.Show();
        }
        //to save all changes in .bin file
        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            allData.Save();
        }
        //exit the app
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void textBox2_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.KeyValue == (char)Keys.Enter)
                button3_Click(sender,e);
        }

        private void helpToolStripMenuItem1_Click(object sender, EventArgs e)
        {
             button1_Click(sender, e);
        }
    }
}
